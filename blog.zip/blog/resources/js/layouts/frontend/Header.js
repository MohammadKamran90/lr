import React from 'react';



const Header = () =>{
    
    return (
      <div className="header">
          <div className="text-center">
              <h4>Welcome To Blog Page</h4>
          </div>
      </div>
    );



}

export default Header;