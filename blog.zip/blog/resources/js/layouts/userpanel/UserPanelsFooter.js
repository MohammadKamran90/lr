import React from 'react';



const UserPanelsFooter = () =>{
    
    return (
      <div className="footer">
          <div className="text-center">
              <h4>All right reserved 2020-2021</h4>
          </div>
      </div>
    );



}

export default UserPanelsFooter;