import React from 'react';
import ReactDOM from 'react-dom';
import Home from './frontend/Home';
import SignIn from './frontend/auth/SignIn';
import SignUp from './frontend/auth/SignUp';
import Dashboard from './userpanel/Dashboard';
import AddPost from './userpanel/AddPost';
import EditPost from './userpanel/EditPost';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';


function App() {
    return (
        <>
            <Router>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/signin" element={<SignIn/>} />
                    <Route path="/signup" element={<SignUp/>} />
                    <Route path="/userdashboard" element={<Dashboard/>} />
                    <Route path="/addpost" element={<AddPost/>} />
                    <Route path="/editpost" element={<EditPost/>} />
                </Routes>
            </Router>
        </>
    );
}

export default App;

if (document.getElementById('app')) {
    ReactDOM.render(<App />, document.getElementById('app'));
}
