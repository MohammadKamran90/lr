import React, { Component } from 'react';
import Sidebar from '../../layouts/userpanel/Sidebar';
import UserPanelsFooter from '../../layouts/userpanel/UserPanelsFooter';




export default class Dashboard extends Component{
    render(){
        return(
            <div className="container">
                <div className="sb-nav-fixed">
                   <div id="layoutSidenav">
                        <div id="layoutSidenav_nav">
                            <Sidebar/>
                        </div>
                        <div id="layoutSidenav_content">
                            <main>
                                User Dashboard
                            </main>
                            <UserPanelsFooter/>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

