import React, { Component } from 'react';
import Sidebar from '../../layouts/userpanel/Sidebar';
import UserPanelsFooter from '../../layouts/userpanel/UserPanelsFooter';




export default class EditPost extends Component{
    render(){
        return(
            <div className="container">
                <div className="sb-nav-fixed">
                   <div id="layoutSidenav">
                        <div id="layoutSidenav_nav">
                            <Sidebar/>
                        </div>
                        <div id="layoutSidenav_content">
                            <main>
                                <div className="card">
                                    <div className="card-body">
                                        <form>
                                            <div className="form-group">
                                                <label>Post Title</label>
                                                <input type="text" className="form-control" name="" value=""/>
                                            
                                            </div>
                                            <div className="form-group">
                                                <label>Post Description</label>
                                                <textarea className="form-control" name="" value=""/>
                                            </div>
                                            <div className="form-group">
                                                <label>Catagory Name</label>
                                                <input type="text" className="form-control" name="" value=""/>
                                            </div>
                                            <button type="submit" className="btn btn-primary">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </main>

                            <UserPanelsFooter/>
                        </div>
                    </div>
                </div>
            </div>
            
        );
    }
}