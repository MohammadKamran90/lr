import React, { Component } from 'react';
import Header from '../../../layouts/frontend/Header';
import Navbar from '../../../layouts/frontend/Navbar';
import Footer from '../../../layouts/frontend/Footer';




export default class SignIn extends Component{
    render(){
        return(
            <div className="container">
                <Header/>
                <Navbar/>
                <div className="card">
                    <div className="card-body">
                        <form>
                            <div className="form-group">
                                <label>Email address</label>
                                <input type="email" className="form-control" name="" value=""/>
                            
                            </div>
                            <div className="form-group">
                                <label>Password</label>
                                <input type="password" className="form-control" name="" value=""/>
                            </div>
                            <button type="submit" className="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
                <Footer/> 
            </div>
        );
    }
}